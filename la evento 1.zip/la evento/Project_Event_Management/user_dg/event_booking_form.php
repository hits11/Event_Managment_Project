

<?php
	


  if(isset($_REQUEST['btnsub']))
  
     {
	   include("connection.php");
	   extract($_POST);
	   $qc=mysqli_query($a,"select date from eb where date='$txtdate'") or die("qf chack !");
	   
	   if(!mysqli_num_rows($qc))
	   {
	   
	$q= mysqli_query($a,"INSERT INTO `eb` (`event`,  `package`, `location`, `date`, `time`, `name`, `phone_no`, `email`) VALUES ('$txtevent', '$txtpackage', '$txtloc', '$txtdate', '$txttime', '$txtname', '$txtphone', '$txtmail')") or die("qf");
	
	// header("location:contact.php");
	  
	  $_SESSION['status']="Event Booking success fully";
	   
	   ?>
	   
		<div id="page-wrapper">
		<?php
		if(isset($_SESSION['status']))
		{
		?>
		<script>
		swal({
  title: "<?php echo $_SESSION['status']; ?>",
  text: "",
  icon: "success",
  button: "ok",
});
		</script>
<?php
	
		unset($_SESSION['status']);
		}
		?>
		<?php
	
		}
	     else
	   {
	   ?>
	   <script>
	   alert("Please Select Different Date !");
	   </script>
	   <?php
	   }
	  }
?>

<section class="about_agile">
		<div class="container">	
					<h3 class="heading-agileinfo white-w3ls">Event Booking<span class="black-w3ls">Events is a Professionally Managed La Evento</span></h3>
			<div class="about-grids">
				
				<div class="abt-rt-grid">
					<div class="w3ls-grid-head text-center">
						<h3>online event booking </h3>
					</div>
					<div class="abt-form text-center">
						<form action="" method="post" onSubmit="return f1() " name="form1">
						<div class="col-sm-12 col-xs-12 w3ls-lt-form">
								<div class="w3ls-pr">
								<select class="sel" name="txtevent" >
								<option value="">Select Event</option>
									<?php
							require("connection.php");
							$q_menu=mysqli_query($a,"select e_name from event")or die("qf menu");
							while($data_m=mysqli_fetch_array($q_menu))
							{
							?>
							<option><?php echo $data_m['e_name'];?></option>
							<?php
							}
							?>
							</select>
								</div>
								</div>
						<div class="col-sm-12 col-xs-12 w3ls-lt-form">
								<div class="w3ls-pr">
								<select class="sel" name="txtpackage" >
											<option value="">Select Package</option>
										<option value="Package 1">Package 1</option>
										<option value="Package 2">Package 2</option>
										<option value="Package 3">Package 3</option>
										
									</select>
								</div>
								</div>
						
						
							<div class="col-sm-4 col-xs-4 w3ls-lt-form">
								<div class="w3ls-pr">
									<select class="sel" name="txtloc">
										<option value="">location</option>
										<option value="Surat">Surat</option>
										<option value="Bhavnagar">Bhavnagar</option>
										<option value="Vadodara">Vadodara</option>
										<option value="Rajkot">Rajkot</option>
									</select>
									<input type="text" name="txtname" placeholder="Name">
								</div>
							</div>
							<div class="col-sm-4 col-xs-4 w3ls-lt-form">
								<div class="w3ls-pr">
									<input type="date" name="txtdate" id="txtdate" min='2023-04-15'  />								<input type="tel" name="txtphone" id="txtphone" placeholder="Phone no"  data-minlength="10" onblur="return validate()"  >
									
								</div>
							</div>
							<div class="col-sm-4 col-xs-4 w3ls-lt-form">
								<div class="w3ls-pr">
									<input type="time" name="txttime" >
									<input type="email" name="txtmail" placeholder="Email" >
								</div>
							</div>
							<div class="clearfix"></div>
							<input type="submit" value="Book Now" name="btnsub">

						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<script>
	
	
	
  function f1()
  {    if(form1.txtevent.value=="")
	  {
	     alert("Select your event");
		 form1.txtevent.focus();
		 return false;
      }
	 else if(form1.txtpackage.value=="")
	  {
	     alert("Select your Package");
		 form1.txtpackage.focus();
		 return false;
      }
      else if(form1.txtloc.value=="")
	  {
	     alert("Enter location");
		 form1.txtloc.focus();
		 return false;
      }
	  else if(form1.txtdate.value=="")	
	  {
	    alert("Enter date");
		form1.txtdate.focus();
		return false;
      }
	  else if(form1.txttime.value=="")	
	  {
	     alert("Enter time");
		 form1.txttime.focus();
		 return false;
	  }
	  else if(form1.txtname.value=="")
	  {
	     alert("Enter name");
		 form1.txtname.focus();
		 return false;
	  }
	  else if(form1.txtphone.value=="")
	  {
	     alert("Enter phone no");
		 form1.txtphone.focus();
		 return false;
		 
	  }
	  else if(form1.txtmail.value=="")
	  {
	      alert("Enter email");
		  form1.txtmail.focus();
		  return false;
	  }
}
  
function validate()
{
  var mob=document.getElementById("txtphone").value;
  var mob_val=/^\d{10}$/;
  if(mob.match(mob_val))
  {
    return true;
  }
  else
  {
    alert("Invalid Phone Number");
	return false;
 }
}
var date=new Date();
var tdate=date.getDate();
var month=date.getMonth() + 1;
if(month < 10){
  month ='0'+month;
  }
if(tdate < 10){
tdate ='0' + tdate;
}
var year=date.getUTCFullYear();
var minDate=tdate + "-" +month + "-" + year;


//document.getElementById("txtdate").setAttribute("min", minDate);

</script>
