<div class="copy-right">
				<div class="container">
				<div class="col-md-12 col-sm-12 col-xs-12 ">
						<div>
						<p>&copy; 2025 Events. All rights reserved | Design by <a href="javascript:void(0)">Là Evènto</a></p>
						</div>
					</div>
				
					<div class="clearfix"></div>
					</div>
			</div>