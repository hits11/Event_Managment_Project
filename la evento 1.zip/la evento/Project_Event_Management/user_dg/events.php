<?php
require_once("connection.php");
$id=$_REQUEST['e'];
$q=mysqli_query($a,"select e_name,package_1,package_2,package_3 from event where event_id=$id")or die("qf");
$data=mysqli_fetch_array($q);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Events</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Events website, Event booking, Events, Online Booking event" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/style.css" type="text/css" rel="stylesheet" media="all">  
<link href="css/font-awesome.css" rel="stylesheet">		<!-- font-awesome icons -->
<!-- //Custom Theme files --> 
<!-- js -->
<script src="js/jquery-2.2.3.min.js"></script>  
<!-- //js -->
<!-- web-fonts -->  
<link href="//fonts.googleapis.com/css?family=Josefin+Sans:300,400,600,700" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<!-- //web-fonts -->
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">  
	<!-- banner -->
	<div class="w3ls-banner-1"> 
		<!-- banner-text --> 
	
	<!-- //banner --> 
			<!-- header -->
		<?php
		include("nav.php");
		?>	
		<!-- //header -->
	</div>	
	<!-- events -->
	<!--Events --> 
		<div class="events-agileits-w3layouts">
		<div class="container">
	
		<h2 class="heading-agileinfo"><?php echo $data['e_name'];?> <span></span></h2>
				<div class="popular-grids">
					
						<div class="col-md-4 popular-grid">
							<img src="../main_dg/web/photo/<?php echo $data['package_1'];?>">
						<div class="popular-text">
								<h5><a href="#" data-toggle="modal" >Silver </a></h5>
								<div class="detail-bottom">
									<ul>
										<li>&#8377;50000</li><br>
										<br>Food</br>
										<br>Minimum Guest:75</br>
										<br>Decoration </br>
										<br>No Deserts </br>
									</ul>
									
								</div>
									
							</div>
						</div>
						<div class="col-md-4 popular-grid">
							<img src="../main_dg/web/photo/<?php echo $data['package_2'];?>">
							<div class="popular-text">
								<h5><a href="#" data-toggle="modal" >Gold</a></h5>
								<div class="detail-bottom">
									<ul> 
									    <li>&#8377;70000</li><br>
										<br>Food</br>
										<br>Minimum Guest:75</br>
										<br>Decoration </br>
										<br>Deserts </br>
									</ul>
									
								</div>
								
							</div>
						</div>
					
						
						<div class="col-md-4 popular-grid">
							<img src="../main_dg/web/photo/<?php echo $data['package_3'];?>">
							<div class="popular-text">
								<h5><a href="#" data-toggle="modal" >Platinum</a></h5>
								<div class="detail-bottom">
									<ul>
										<li>&#8377;100000</li><br>
										<br>Food</br>
										<br>Minimum Guest:75</br>
										<br>Decoration & Parties </br>
										<br>Deserts & Ice-Cream</br>
									</ul>
								
								</div>
								
							</div>
						</div>
				</div>
					<div class="clearfix"></div>
					
		</div>
		</div>
<!-- //Events --> 

	<!-- //events -->
<!-- footer-top -->	
	<?php
	include("footer_top.php");
	?>
<!-- /footer-top -->							

<!-- footer -->
			<?php
			include("footer.php");
			?>
			
<!-- //footer -->
<!-- bootstrap-modal-pop-up -->
	<div class="modal video-modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModal">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					Events
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
				</div>
					<div class="modal-body">
						<img src="images/g8.jpg" alt=" " class="img-responsive" />
						<p>Ut enim ad minima veniam, quis nostrum 
							exercitationem ullam corporis suscipit laboriosam, 
							nisi ut aliquid ex ea commodi consequatur? Quis autem 
							vel eum iure reprehenderit qui in ea voluptate velit 
							esse quam nihil molestiae consequatur, vel illum qui 
							dolorem eum fugiat quo voluptas nulla pariatur.
							<i>" Quis autem vel eum iure reprehenderit qui in ea voluptate velit 
								esse quam nihil molestiae consequatur.</i></p>
					</div>
			</div>
		</div>
	</div>
<!-- //bootstrap-modal-pop-up --> 
<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>

<script src="js/jquery-2.2.3.min.js"></script> 
	
<!-- skills -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
	<script src="js/bootstrap.js"></script>
<!-- //for bootstrap working -->
<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
	
<!-- //here ends scrolling icon -->
</body>
</html>