
</tr>
                          <tr>
                            <th scope="row">3</th>
                            <td> <input type="text" class="form-control" ></td>
                            <td> <input type="number" class="form-control text-end"></td>
                            <td><input type="text" class="form-control text-end"></td>
                            <td><input type="number" class="form-control text-end"></td>
                            <td><input type="number" class="form-control text-end"></td>
                            <td class="NoPrint"><button type="button" class="btn btn-danger">X</button></td>

                          </tr>
                          <tr>
                            <th scope="row">4</th>
                            <td> <input type="text" class="form-control" ></td>
                            <td> <input type="number" class="form-control text-end"></td>
                            <td><input type="text" class="form-control text-end"></td>
                            <td><input type="number" class="form-control text-end"></td>
                            <td><input type="number" class="form-control text-end"></td>
                            <td class="NoPrint"><button type="button" class="btn btn-danger">X</button></td>