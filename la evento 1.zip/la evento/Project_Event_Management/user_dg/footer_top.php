<div class="footer-top">
		<div class="container">
			<div class="col-md-4 foot-left">
				<h3>About Us</h3>
			
				<p>Great minds discuss ideas; average minds discuss events; small minds discuss people.</p>
			</div>
			<div class="col-md-4 foot-left">
					<h3>Get In Touch</h3>
					<p>You Need any help contact hear </p>
				
						<div class="contact-btm">
							<span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>
							<p>356 Dada ni vadi, Bhavnagar, Gujrat 364001.</p>
						</div>
						<div class="contact-btm">
							<span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>
							<p>+91 90540 80390</p>
						<div class="contact-btm">
						</div>
							<span class="fa fa-envelope-o" aria-hidden="true"></span>
							<p><a href="mailto:laevento103@email.com">laevento103@gmail.com</a></p>
						</div>
						<div class="clearfix"></div>

			</div>
			<div class="col-md-4 foot-left">
				<h3>Latest Events</h3>
				<ul>
					<li><a href="#" data-lightbox="example-set"  data-toggle="modal" data-target="#myModal"><img src="images/g2.jpg" alt="" class="img-responsive"></a></li>
					<li><a href="#" data-lightbox="example-set" data-toggle="modal" data-target="#myModal"><img src="images/g3.jpg" alt="" class="img-responsive"></a></li>
					<li><a href="#" data-lightbox="example-set" data-toggle="modal" data-target="#myModal"><img src="images/g4.jpg" alt="" class="img-responsive"></a></li>
					<li><a href="#" data-lightbox="example-set"data-toggle="modal" data-target="#myModal"><img src="images/g1.1.jpg" alt="" class="img-responsive"></a></li>
				</ul>
				<div class="clearfix"></div>
			</div>
			
		</div>
	</div>