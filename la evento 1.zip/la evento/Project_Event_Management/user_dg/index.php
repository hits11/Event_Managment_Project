<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>HOME</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Events website, Event booking, Events, Online Booking event" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/style.css" type="text/css" rel="stylesheet" media="all">  
<link href="css/style1.css" type="text/css" rel="stylesheet" media="all">  
<link href="css/font-awesome.css" rel="stylesheet">		<!-- font-awesome icons -->
<!-- //Custom Theme files --> 
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<!-- js -->
<script src="js/jquery-2.2.3.min.js"></script> 
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script> 
<!-- //js -->
<!-- web-fonts -->  
<link href="/fonts.googleapis.com/css?family=Josefin+Sans:300,400,600,700" rel="stylesheet">
<link href="fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<!-- //web-fonts -->
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">  
	<!-- banner -->
	<div id="home" class="w3ls-banner"> 

		<!-- banner-text -->
		<div class="slider">
			<div class="callbacks_container">
				<ul class="rslides callbacks callbacks1" id="slider4">
					<li>
						<div class="w3layouts-banner-top ">

							<div class="container">
								<div class="agileits-banner-info">
									<h3>“It's your special day —   <span>get out there and celebrate!"</span></h3>
												
									
								</div>	
							</div>
						</div>
					</li>
					<li>
						<div class="w3layouts-banner-top w3layouts-banner-top1">
							<div class="container">
								<div class="agileits-banner-info">
									<h3>I'm gonna live like tomorrow doesn't exist. </h3>
										
								</div>	
							</div>
						</div>
					</li>
					<li>
						<div class="w3layouts-banner-top w3layouts-banner-top2">
							<div class="container">
								<div class="agileits-banner-info">
								<h3>“The highest happiness on earth is the happiness of marriage.”</h3>
										
								</div>
								
							</div>
						</div>
					</li>
				</ul>
			</div>
			<div class="clearfix"> </div>
			
			<!--banner Slider starts Here-->
		</div>
		 
 
	</div>	
	<!-- //banner --> 
			<!-- header -->
		<?php
		include("nav.php");
		?>	
		
		
		<!-- //header -->
		<!-- ser_agile -->
		<div class="ser_agile">
			<div class="container">
			<h2 class="heading-agileinfo">Welcome<span>Events is a professionally managed La Evento</span></h2>
			<p>Event management is the process of creating and maintaining an event. This process spans from the very beginning of planning all the way to post-event strategizing. At the start, an event manager makes planning decisions, such as the time, location, and theme of their event.</p>
			<div class="ser_w3l">  
			  <div class="outer-wrapper">
				<div class="inner-wrapper">
				  <div class="icon-wrapper">
					<i class="fa fa-birthday-cake" aria-hidden="true"></i>
				  </div>
				  <div class="content-wrapper">
					<h4>Birthday</h4>
					<p>“Count your life by smiles, not tears. Count your age by friends, not years. Happy birthday!”</p>
				  </div>
				</div>
			  </div>
			  <div class="outer-wrapper">
				<div class="inner-wrapper">
				  <div class="icon-wrapper">
					<i class="fa fa-volume-up" aria-hidden="true"></i>
				  </div>
				  <div class="content-wrapper">
					<h4>Party</h4>
					<p>"This is my moment I just feel so alive."-Life is a party.</p>
					
					
				  </div>
				</div>
			  </div>
			  <div class="outer-wrapper">
				<div class="inner-wrapper">
				  <div class="icon-wrapper">
					<i class="fa fa-globe" aria-hidden="true"></i>
				  </div>
				  <div class="content-wrapper">
					<h4>Weddings</h4>
					<p>“I would rather share one lifetime with you than face all the ages of this world alone.”</p>
				  </div>
				</div>
			  </div>
			  <div class="outer-wrapper">
				<div class="inner-wrapper">
				  <div class="icon-wrapper">
					<i class=" fa fa-camera-retro" aria-hidden="true"></i>
				  </div>
				  <div class="content-wrapper">
					<h4>Photography</h4>
					<p>"In the world of photography, you get to share a captured moment with other people."</p>
				  </div>
				</div>
			  </div>
			  <div class="outer-wrapper">
				<div class="inner-wrapper">
				  <div class="icon-wrapper">
					<i class="fa fa-cutlery" aria-hidden="true"></i>
				  </div>
				  <div class="content-wrapper">
					<h4>Catering</h4>
					<p>A party with great food is a party creating memories.</p>
				  </div>
				</div>
			  </div>
			  <div class="outer-wrapper">
				<div class="inner-wrapper">
				  <div class="icon-wrapper">
					<i class="fa fa-tasks" aria-hidden="true"></i>
				  </div>
				  <div class="content-wrapper">
					<h4>Promotions</h4>
					<p>A party without cake is just a meeting.-Life is a party.</p>
				  </div>
				</div>
			  </div>
			  <div class="clearfix"></div>
			  </div>
			</div>
		</div>
	<!-- //ser_agile -->
<!-- Stats -->
	
	<!-- //Stats -->
	
	<!-- showcase_w3layouts -->	
	<div class="showcase_w3layouts">
		<div class="container">
		<h3 class="heading-agileinfo">Services<span>Events is a Professionally Managed La Event</span></h3>
			<div class="our_agile-info">
			<div class="showcase">
				<div class="thumbnail thumbnail--awesome">
					<div class="thumbnail__overlay">
						
					</div>
				</div>
				<div class="desc">
				
					<h4>Birthday</h4>
					<p>“Forget the past; look forward to the future, for the best things are yet to come.”
					</p>
				</div>
			</div>
			
			<div class="showcase showcase--inverted">
				<div class="desc">
					
					<h4>Wedding</h4>
					<p>“If we look at the world with a love of life, the world will reveal its beauty to us.”
					</p>
				</div>
				<div class="thumbnail thumbnail--awesome1">
					<div class="thumbnail__overlay">
						
					</div>
				</div>
			</div>
			<div class="showcase">
				<div class="thumbnail thumbnail--awesome2">
					<div class="thumbnail__overlay">
						
					</div>
				</div>
				<div class="desc">
				
					<h4>Photography</h4>
					<p>"The camera is an instrument that teaches people how to see without a camera."
					</p>
				</div>
			</div>
			<div class="showcase showcase--inverted">
				<div class="desc">
					
					<h4>Catering</h4>
					<p>Catering is not just all about food. It’s about excellent service as well.
					</p>
				</div>
				<div class="thumbnail thumbnail--awesome3">
					<div class="thumbnail__overlay">
					
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
			</div>
		</div>
	</div>
<!-- //showcase_w3layouts -->	
<?php
include("event_booking_form.php");
?>
	<!--testimonials-->
<div class="testimonials">
	<div class="container">
		<h3 class="heading-agileinfo">Event Manager Says<span>Events is a professionally managed Event</span></h3>
		<div class="flex-slider">
			<ul id="flexiselDemo1">			
				<li>
					<div class="laptop">
						<div class="col-md-8 team-right">
							<p>“Count your life by smiles, not tears. Count your age by friends, not years. Happy birthday!”</p>
							<div class="name-w3ls">
								<h5>Dhola Krish</h5>
								<span>Catering Services</span>
							</div>
				 		</div>
						<div class="col-md-4 team-left">
							<img class="img-responsive" src="images/demo1.jpg" alt=" " />
						</div>
						<div class="clearfix"></div>
					</div>
				</li>
				<li>
					<div class="laptop">
						<div class="col-md-8 team-right">
							<p>“If we look at the world with a love of life, the world will reveal its beauty to us.”</p>
							<div class="name-w3ls">
								<h5>Goyani Hit</h5>
								<span>Bithday Decoration</span>
							</div>
						</div>
						<div class="col-md-4 team-left">
							<img class="img-responsive" src="images/demo2.jpg" alt=" " />
						</div>
						<div class="clearfix"></div>
					</div>
				</li>
				

			</ul>
			
		</div>

	</div>
</div>
<!--//testimonials-->

<!-- footer-top -->	
	<?php
	include("footer_top.php");
	?>
<!-- /footer-top -->							

<!-- footer -->
			<?php
			 include("footer.php");
			?>
			
<!-- //footer -->

<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>

<script src="js/jquery-2.2.3.min.js"></script> 
	
<!-- skills -->

						<script src="js/responsiveslides.min.js"></script>
			<script>
						// You can also use "$(window).load(function() {"
						$(function () {
						  // Slideshow 4
						  $("#slider4").responsiveSlides({
							auto: true,
							pager:true,
							nav:false,
							speed: 500,
							namespace: "callbacks",
							before: function () {
							  $('.events').append("<li>before event fired.</li>");
							},
							after: function () {
							  $('.events').append("<li>after event fired.</li>");
							}
						  });
					
						});
			</script>
			<script>
								// You can also use "$(window).load(function() {"
								$(function () {
								  // Slideshow 4
								  $("#slider3").responsiveSlides({
									auto: true,
									pager:false,
									nav:true,
									speed: 500,
									namespace: "callbacks",
									before: function () {
									  $('.events').append("<li>before event fired.</li>");
									},
									after: function () {
									  $('.events').append("<li>after event fired.</li>");
									}
								  });
							
								});
							 </script>

<!-- start-smoth-scrolling -->
<!-- OnScroll-Number-Increase-JavaScript -->
	<script type="text/javascript" src="js/numscroller-1.0.js"></script>
<!-- //OnScroll-Number-Increase-JavaScript -->
<!--flexiselDemo1 -->
 <script type="text/javascript">
							$(window).load(function() {
								$("#flexiselDemo1").flexisel({
									visibleItems: 2,
									animationSpeed: 1000,
									autoPlay: true,
									autoPlaySpeed: 3000,    		
									pauseOnHover: true,
									enableResponsiveBreakpoints: true,
									responsiveBreakpoints: { 
										portrait: { 
											changePoint:480,
											visibleItems: 1
										}, 
										landscape: { 
											changePoint:640,
											visibleItems: 1
										},
										tablet: { 
											changePoint:991,
											visibleItems: 1
										}
									}
								});
								
							});
			</script>
			<script type="text/javascript" src="js/jquery.flexisel.js"></script>
<!--//flexiselDemo1 -->

<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
	<script src="js/bootstrap.js"></script>
<!-- //for bootstrap working -->
<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
<!-- //here ends scrolling icon -->
</body>
</html>