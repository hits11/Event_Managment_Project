

<!DOCTYPE html>
<html lang="en">
<head>
<title>About Us</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Events website, Event booking, Events, Online Booking event" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/style.css" type="text/css" rel="stylesheet" media="all">  
<link href="css/font-awesome.css" rel="stylesheet">		<!-- font-awesome icons -->
<!-- //Custom Theme files --> 
<!-- js -->
<script src="js/jquery-2.2.3.min.js"></script>  
<!-- //js -->
<!-- web-fonts -->  
<link href="//fonts.googleapis.com/css?family=Josefin+Sans:300,400,600,700" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<!-- //web-fonts -->
</head>
<style>

.w3ls-banner-1 {
  background-position: center;
    background-size: cover;	
	-webkit-background-size: cover;	
	-moz-background-size: cover;
	-o-background-size: cover;		
	-moz-background-size: cover;
	min-height:100vh;
}
</style>
<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">  
	<!-- banner -->
	<div class="w3ls-banner-1"> 
		<!-- banner-text --> 
	
	<!-- //banner --> 
			<!-- header -->
			<?php
			include("nav.php");
			?>
		<!-- //header -->
	</div>	
<!-- about -->
<!-- about -->
	<div class="about">
		<div class="container">
		<h2 class="heading-agileinfo">About Us<span>Events is a professionally managed  La Evento</span></h2>
			<div class="about-grids-1">
				<div class="col-md-5 wthree-about-left">
					<div class="wthree-about-left-info">
						<img src="images/g3.jpg" alt="" />
					</div>
				</div>
				<div class="col-md-7 agileits-about-right">
					<h2>- Events are the best teacher for us. We try to learn from people, there is always some bend to it.</h2><br>
					<h3>- The best events are not just beautiful, they are also Fantabulous , Memorable  .</h3><br>
					<h5>- We Make Your Event Memorable!</h5>
					</p>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //about -->
	<!-- offers -->
	
	<!-- offers -->
		<!-- about-team -->
<!-- Wrapper for Centering -->
<div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; background-color: #f4f4f4; padding: 20px; font-family: 'Segoe UI', sans-serif;">

  <!-- Flexbox Container for Two Cards -->
  <div style="display: flex; flex-wrap: wrap; gap: 20px; justify-content: center; max-width: 900px;">

    <!-- Profile Card 1 -->
    <div style="background: #fff; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); width: 280px; text-align: center; overflow: hidden;">
      <img src="images/demo1.jpg" alt="Hit H. Goyani" style="width: 100%; height: auto;">
      <div style="padding: 15px;">
        <h3 style="margin-bottom: 5px;">Hit H. Goyani</h3>
        <p style="color: #ff6600; font-size: 14px;">Birthday Decorations</p>
        <p style="color: #666; font-size: 12px; margin: 10px 0;">Expert in making birthdays special with customized decorations and themes.</p>
        <p><strong>📞</strong> +91 78619 63651</p>
        <p><strong>📧</strong> hit.goyani1010@gamil.com</p>
      </div>
    </div>

    <!-- Profile Card 2 -->
    <div style="background: #fff; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); width: 280px; text-align: center; overflow: hidden;">
      <img src="images/demo2.jpg" alt="Krish P. Dhola" style="width: 100%; height: auto;">
      <div style="padding: 15px;">
        <h3 style="margin-bottom: 5px;">Krish P. Dhola</h3>
        <p style="color: #ff6600; font-size: 14px;">Catering Service</p>
        <p style="color: #666; font-size: 12px; margin: 10px 0;">Serving delicious food for all types of events with the best quality.</p>
        <p><strong>📞</strong> +91 90540 80390</p>
        <p><strong>📧</strong> krishpdhola@gamil.com</p>
      </div>
    </div>

  </div>
</div>

	<!-- //about-team -->
<!-- about -->
<!-- footer-top -->	
	<?php
	include("footer_top.php");
	?>
<!-- /footer-top -->							

<!-- footer -->
			<?php
			include("footer.php");
					?>
			
<!-- //footer -->

<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>

<script src="js/jquery-2.2.3.min.js"></script> 
	
<!-- skills -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
	<script src="js/bootstrap.js"></script>
<!-- //for bootstrap working -->
<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
<!-- //here ends scrolling icon -->
</body>
</html>