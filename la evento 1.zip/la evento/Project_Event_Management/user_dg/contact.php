
<?php
session_start();
?>   
<?php
   if(isset($_REQUEST['btnsub']))
   {
      include("connection.php");
	    extract($_POST);
		mysqli_query($a,"INSERT INTO `contact` (`name`, `email`, `subject`, `message`) VALUES ('$txtname', '$txtmail', '$txtsub', '$txtmsg')");
	    header("location:contact.php");
		
    }
	 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Contact Us</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Events website, Event booking, Events, Online Booking event" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/style.css" type="text/css" rel="stylesheet" media="all">  
<link href="css/font-awesome.css" rel="stylesheet">		<!-- font-awesome icons -->
<!-- //Custom Theme files --> 
<!-- js -->
<script src="js/jquery-2.2.3.min.js"></script>  
<!-- //js -->
<!-- web-fonts -->  
<link href="//fonts.googleapis.com/css?family=Josefin+Sans:300,400,600,700" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<!-- //web-fonts -->
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">  
	<!-- banner -->
	<div class="w3ls-banner-1"> 
		<!-- banner-text --> 
	
	<!-- //banner --> 
			<!-- header -->
			<?php
			include("nav.php");
			?>
		<!-- //header -->
	</div>	
<!-- contact -->	
	<div class="w3ls_address_mail_footer_grids">
	<div class="container">
	<h2 class="heading-agileinfo">Contact<span>Events is a Professionally Managed La Evento</span></h2>
		
		<div class="col-md-6 contact-form">
				<h4 class="white-w3ls">Contact Form</h4>
				<form action="#" method="post" onSubmit="return f1();" name="form1">
					<div class="styled-input agile-styled-input-top">
						<input type="text" name="txtname" >
						<label>Name</label>
						<span></span>
					</div>
					<div class="styled-input">
						<input type="email" name="txtmail" > 
						<label>Email</label>
						<span></span>
					</div> 
					<div class="styled-input">
						<input type="text" name="txtsub" >
						<label>Subject</label>
						<span></span>
					</div>
					<div class="styled-input">
						<textarea name="txtmsg" ></textarea>
						<label>Message</label>
						<span></span>
					</div>	 
					<input type="submit" value="SEND" name="btnsub">
				</form>
			</div>
			<div class="col-md-6 contactright">
				<h3>Contact Address</h3>
				<div class="w3ls_footer_grid_left">
					<div class="wthree_footer_grid_left">
						<i class="fa fa-map-marker" aria-hidden="true"></i>
					</div>
					<p>356 Dada ni vadi, <span>Bhavanagar Gujrat - 364001.</span></p>
				</div>
				<div class="w3ls_footer_grid_left">
					<div class="wthree_footer_grid_left">
						<i class="fa fa-phone" aria-hidden="true"></i>
					</div>
					<p>+(91) 78619 63651<span>+(91) 90540 80390</span></p>
				</div>
				<div class="w3ls_footer_grid_left">
					<div class="wthree_footer_grid_left">
						<i class="fa fa-envelope-o" aria-hidden="true"></i>
					</div>
					<p><a href="mailto:laevento103@gmail.com">laevento103@gmail.com</a> 
						<span><a href="mailto:laevento103@gmail.com">laevento103@gmail.com</a></span></p>
				</div>
			</div>
			<div class="clearfix"> </div>
	</div>
</div>
<!-- //contact -->	
<!-- footer-top -->	
	<?php
	include("footer_top.php");
	?>
<!-- /footer-top -->							

<!-- footer -->
			<?php
			include("footer.php");
			?>
			
<!-- //footer -->
<!-- bootstrap-modal-pop-up -->
	<div class="modal video-modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModal">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					Events
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
				</div>
					<div class="modal-body">
						
						<p>We organise best Event and We Setisfy our Clients With Best EventManagment
							<i>" This Event is Organize by La evento.</i></p>
					</div>
			</div>
		</div>
	</div>
<!-- //bootstrap-modal-pop-up --> 
<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>

<script src="js/jquery-2.2.3.min.js"></script> 
	
<!-- skills -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
	<script src="js/bootstrap.js"></script>
<!-- //for bootstrap working -->
<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
<!-- //here ends scrolling icon -->
</body>
</html>
<script>
function f1()
{
   if(form1.txtname.value=="")
   {
        alert("Enter name");
		form1.txtname.focus();
		return false;
		
	}
	else if(form1.txtmail.value=="")
	{
	   alert("Enter email");
	   form1.txtmail.focus();
	   return false;
	  }
	 else if(form1.txtsub.value=="")
	{
	   alert("Enter subject");
	   form1.txtsub.focus();
	   return false;
	  }
	  else if(form1.txtmsg.value=="")
	{
	   alert("Enter message");
	   form1.txtmsg.focus();
	   return false;
	  }
	 
	}
	
</script>
