<div class="header-w3layouts"> 
			<!-- Navigation -->
			<nav class="navbar navbar-default navbar-fixed-top">
				<div class="container">
					<div class="navbar-header page-scroll">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
							<span class="sr-only"> la Evento</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<h1><a class="navbar-brand" href="index.php">Là Evènto</a></h1>
					</div> 
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse navbar-ex1-collapse">
						<ul class="nav navbar-nav navbar-right">
							<!-- Hidden li included to remove active class from about link when scrolled up past about section -->
							<li class="hidden"><a class="page-scroll" href="#page-top"></a>	</li>
							<li><a class="hvr-sweep-to-right" href="index.php">Home</a></li>
							<li><a class="hvr-sweep-to-right" href="about.php">About</a></li>
							<li class="dropdown">
									<a href="#" class="dropdown-toggle hvr-sweep-to-right" data-hover="Pages" data-toggle="dropdown">Evènts <b class="caret"></b></a>			
								
							
									<ul class="dropdown-menu">
																		<?php
							require("connection.php");
							$q_menu=mysqli_query($a,"select * from event")or die("qf menu");
							while($data_m=mysqli_fetch_array($q_menu))
							{
							?>
							

									
					<!--	<li><a class="hvr-sweep-to-right" href="events.php"></a></li>-->
					<li>	<a class="hvr-sweep-to-right" href="events.php?e=<?php echo $data_m['event_id'];?>"><?php echo $data_m['e_name'];?></a>	</li>			
										<?php
										}
										?>
									</ul>
									
							  </li>
							  
							 
							<li><a class="hvr-sweep-to-right" href="gallery.php">Gallery</a></li>
							<li><a class="hvr-sweep-to-right" href="contact.php">Contact</a></li>
						</ul>
					</div>
					<!-- /.navbar-collapse -->
				</div>
				<!-- /.container -->
			</nav>  
		</div>