
<!DOCTYPE html>
<html lang="en">
<head>
<title>Gallery</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Events website, Event booking, Events, Online Booking event" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/style.css" type="text/css" rel="stylesheet" media="all">  
<link href="css/font-awesome.css" rel="stylesheet">		<!-- font-awesome icons -->
<link rel="stylesheet" href="css/lightbox.css">
<!-- //Custom Theme files --> 
<!-- js -->
<script src="js/jquery-2.2.3.min.js"></script>  
<!-- //js -->
<!-- web-fonts -->  
<link href="//fonts.googleapis.com/css?family=Josefin+Sans:300,400,600,700" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<!-- //web-fonts -->
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">  
	<!-- banner -->
	<div class="w3ls-banner-1"> 
		<!-- banner-text --> 
	
	<!-- //banner --> 
			<!-- header -->
			<?php
			include("nav.php");
			?>
		<!-- //header -->
	</div>	
	<!-- gallery -->
	<div class="gallery">
		<div class="container">
			<h2 class="heading-agileinfo">Gallery<span>Events is a professionally Managed La Event</span></h2>
			<div class="gallery-grids">
					<div class="col-md-4 gallery-grid">
						<div class="grid">
							<figure class="effect-apollo">
								<a class="example-image-link" href="images/g1.jpg" data-lightbox="example-set" data-title="">
									<img src="images/g1.jpg" alt="" height="230"/>
									<figcaption>
										<p>Varrachha, Rachna circle SURAT</p>
									</figcaption>	
							  </a>
						  </figure>
						</div>
					</div>
					<div class="col-md-4 gallery-grid">
						<div class="grid">
							<figure class="effect-apollo">
								<a class="example-image-link" href="images/g2.jpg" data-lightbox="example-set" data-title="">
									<img src="images/g2.jpg" alt="" />
									<figcaption>
										<p>Akash chok, Panvadi VADODARA</p>
									</figcaption>	
							  </a>
						  </figure>
						</div>
					</div>
					<div class="col-md-4 gallery-grid">
						<div class="grid">
							<figure class="effect-apollo">
								<a class="example-image-link" href="images/g3.jpg" data-lightbox="example-set" data-title="">
									<img src="images/g3.jpg" alt="" />
									<figcaption>
										<p>Lalji temple, Bell circle AHMEDABAD</p>
									</figcaption>		
							  </a>
						  </figure>
						</div>
					</div>
					<div class="col-md-4 gallery-grid">
						<div class="grid">
							<figure class="effect-apollo">
								<a class="example-image-link" href="images/g4.jpg" data-lightbox="example-set" data-title="">
									<img src="images/g4.jpg" alt="" />
									<figcaption>
										<p>Tilak Vadi, Sanket so. SURAT</p>
									</figcaption>	
							  </a>
						  </figure>
						</div>
					</div>
					<div class="col-md-4 gallery-grid">
						<div class="grid">
							<figure class="effect-apollo">
								<a class="example-image-link" href="images/g5.jpg" data-lightbox="example-set" data-title="">
									<img src="images/g5.jpg" alt="" height="230" />
									<figcaption>
										<p>Amansila , Ghogha circle BHAVANAGAR</p>
									</figcaption>	
							  </a>
						  </figure>
						</div>
					</div>
					<div class="col-md-4 gallery-grid">
						<div class="grid">
							<figure class="effect-apollo">
								<a class="example-image-link" href="images/g6.jpg" data-lightbox="example-set" data-title="">
									<img src="images/g6.jpg" alt="" />
									<figcaption>
										<p>Yatri so.,Manak bag RAJKOT</p>
									</figcaption>		
							  </a>
						  </figure>
						</div>
					</div>
					<div class="col-md-4 gallery-grid">
						<div class="grid">
							<figure class="effect-apollo">
								<a class="example-image-link" href="images/g7.jpg" data-lightbox="example-set" data-title="">
									<img src="images/g7.jpg" alt="" />
									<figcaption>
										<p>Oleman chok, kalubhid BHAVANAGAR</p>
									</figcaption>	
							  </a>
						  </figure>
						</div>
					</div>
					<div class="col-md-4 gallery-grid">
						<div class="grid">
							<figure class="effect-apollo">
								<a class="example-image-link" href="images/g8.jpeg" data-lightbox="example-set" data-title="">
									<img src="images/g8.jpeg" alt="" />
									<figcaption>
										<p>Bhid bajar, Manulink so. SURAT</p>
									</figcaption>	
							  </a>
						  </figure>
						</div>
					</div>
					<div class="col-md-4 gallery-grid">
						<div class="grid">
							<figure class="effect-apollo">
								<a class="example-image-link" href="images/g9.jpg" data-lightbox="example-set" data-title="">
									<img src="images/g9.jpg" alt="" />
									<figcaption>
										<p>Jagubha, Ram vadi VADODARA</p>
									</figcaption>		
							  </a>
						  </figure>
						</div>
					</div>
					<div class="clearfix"> </div>
					<script src="js/lightbox-plus-jquery.min.js"> </script>
			</div>
		</div>
	</div>
	<!-- //gallery -->


<!-- footer-top -->	
	<?php
	include("footer_top.php");
	?>
<!-- /footer-top -->							

<!-- footer -->
			<?php
			include("footer.php");
			?>
			
<!-- //footer -->
<!-- bootstrap-modal-pop-up -->
	
<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>

<script src="js/jquery-2.2.3.min.js"></script> 
	
<!-- skills -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
	<script src="js/bootstrap.js"></script>
<!-- //for bootstrap working -->
<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
<!-- //here ends scrolling icon -->
</body>
</html>