-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 14, 2025 at 04:28 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `event`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aid` int(3) NOT NULL,
  `name` varchar(25) NOT NULL,
  `mobile` bigint(10) NOT NULL,
  `email` varchar(35) NOT NULL,
  `photo` varchar(400) NOT NULL,
  `loginid` varchar(20) NOT NULL,
  `password` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `name`, `mobile`, `email`, `photo`, `loginid`, `password`) VALUES
(90, 'bhuro', 3232323232, 'bhuro@gami.com', '3.png', 'hits', '1234'),
(91, 'piyush', 6565656778, 'piyush@gmail.com', '2.png', 'piyush', '6460'),
(92, 'kiks', 6326, 'bbjh@gmail.com', 'hanumaanjii.jpg', 'kiks', '1234'),
(93, 'kiks', 9123456789, 'hubtyb@gmail.com', 'WhatsApp Image 2022-11-21 at 1.36.00 PM.jpeg', 'heet', '1234'),
(94, 'kiks', 9123456789, 'hubtyb@gmail.com', 'hanumaanjii.jpg', 'heet', '1234'),
(95, 'Kiks', 9123456789, 'hubtyb@gmail.com', 'hanumaanjii.jpg', 'heet', '1234'),
(96, 'Hit goyani', 9123456789, 'hubtyb@gmail.com', 'hanumaanjii.jpg', 'heet', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `c_id` int(3) NOT NULL,
  `name` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  `subject` varchar(15) NOT NULL,
  `message` varchar(75) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`c_id`, `name`, `email`, `subject`, `message`) VALUES
(10, 'piyush', 'piyush@gmail.com', 'party', 'Drink is available  in party ?'),
(11, 'Raj', 'raju@gmail.com', 'Marriage', 'Any photogapher is available ?'),
(12, 'kishan', 'kishan@gmail.com', 'Birthday', 'Cake is avilable ?'),
(13, 'gfchbj', 'hubtyb@gmail.com', 'nnuj', 'jbtfrfgfc tcty'),
(14, 'hit', 'hit@gmail.com', 'birtaday', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `eb`
--

CREATE TABLE `eb` (
  `eid` int(3) NOT NULL,
  `event` varchar(50) NOT NULL,
  `package` varchar(30) NOT NULL,
  `location` varchar(75) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone_no` int(10) NOT NULL,
  `email` varchar(35) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `eb`
--

INSERT INTO `eb` (`eid`, `event`, `package`, `location`, `date`, `time`, `name`, `phone_no`, `email`) VALUES
(40, 'Birthday', 'Package 1', 'Vadodara', '2023-04-27', '10:20:00', 'kishan', 2147483647, 'kishan@gmail.com'),
(41, 'Party', 'Package 1', 'rajkot', '2023-04-29', '10:20:00', 'Mohit', 2147483647, 'mohit@gmail.com'),
(42, 'Birthday', 'Package 2', 'Bhavnagar', '2023-04-30', '01:00:00', 'sangita', 2147483647, 'sngita@gmail.com'),
(43, 'Marriage', 'Package 3', 'Surat', '2023-05-02', '16:27:00', 'Ramji', 2147483647, 'ramjibhai@gmail.com'),
(44, 'Birthday', 'Package 2', 'Bhavnagar', '2023-05-01', '18:52:00', 'm kjnjn', 1234567891, 'hubtyb@gmail.com'),
(46, 'Birthday', 'Package 1', 'Bhavnagar', '2023-08-31', '05:00:00', 'Kishan', 1234567891, 'hubtyb@gmail.com'),
(47, 'Marriage', 'Package 1', 'Surat', '2023-04-16', '18:57:00', 'om', 2147483647, 'om10@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `event_id` int(3) NOT NULL,
  `e_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_mysql500_ci NOT NULL,
  `package_1` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_mysql500_ci NOT NULL,
  `package_2` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_mysql500_ci NOT NULL,
  `package_3` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_mysql500_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`event_id`, `e_name`, `package_1`, `package_2`, `package_3`) VALUES
(26, 'Birthday', 'birthday3.jpg', 'b2.jpg', 'bb2.jpg'),
(27, 'Marriage', 'w2.jpg', 'w3.jpg', 'w4.jpg'),
(28, 'Party', 'pa1.jpg', 'g4.jpg', 'small_party 3.jpg'),
(29, 'conf', 'WhatsApp Image 2022-11-21 at 1.35.51 PM.jpeg', 'WhatsApp Image 2022-11-21 at 1.36.00 PM.jpeg', 'WhatsApp Image 2022-11-21 at 1.36.06 PM.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `i_id` int(3) NOT NULL,
  `event` varchar(30) NOT NULL,
  `package` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `amount` varchar(6) NOT NULL,
  `sgst` varchar(5) NOT NULL,
  `cgst` varchar(5) NOT NULL,
  `discount` varchar(5) NOT NULL,
  `total` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`i_id`, `event`, `package`, `date`, `amount`, `sgst`, `cgst`, `discount`, `total`) VALUES
(28, 'Birthday', '', '2023-03-27', '50000', '18', '18', '10', '63000'),
(29, 'Party', '', '2023-03-29', '70000', '18', '18', '10', '88200'),
(30, 'Marriage', '', '2023-03-30', '90000', '18', '18', '10', '113400'),
(31, 'Birthday', '', '2023-09-16', '50000', '18', '18', '10', '63000'),
(32, 'Marriage', '', '2025-02-09', '50000', '18', '18', '10', '63000');

-- --------------------------------------------------------

--
-- Table structure for table `main_cat`
--

CREATE TABLE `main_cat` (
  `mc_id` int(3) NOT NULL,
  `mc_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `main_cat`
--

INSERT INTO `main_cat` (`mc_id`, `mc_name`) VALUES
(3, 'sungit'),
(4, 'catering'),
(7, 'dj'),
(10, 'gajani'),
(11, 'kishan12');

-- --------------------------------------------------------

--
-- Table structure for table `sub_cat`
--

CREATE TABLE `sub_cat` (
  `sc_id` int(3) NOT NULL,
  `mc_name` varchar(30) NOT NULL,
  `sc_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `eb`
--
ALTER TABLE `eb`
  ADD PRIMARY KEY (`eid`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`i_id`);

--
-- Indexes for table `main_cat`
--
ALTER TABLE `main_cat`
  ADD PRIMARY KEY (`mc_id`);

--
-- Indexes for table `sub_cat`
--
ALTER TABLE `sub_cat`
  ADD PRIMARY KEY (`sc_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `aid` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `c_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `eb`
--
ALTER TABLE `eb`
  MODIFY `eid` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `event_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `i_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `main_cat`
--
ALTER TABLE `main_cat`
  MODIFY `mc_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `sub_cat`
--
ALTER TABLE `sub_cat`
  MODIFY `sc_id` int(3) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
