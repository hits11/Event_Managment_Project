<?php
   include("connection.php");
   $d=$_REQUEST['d'];
   
   $q=mysqli_query($a,"delete  from invoice where i_id=$d");
   header("location:display_invoice.php");
?>