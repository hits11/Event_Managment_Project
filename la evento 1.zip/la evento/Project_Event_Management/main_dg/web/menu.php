<div class=" sidebar" role="navigation">
            <div class="navbar-collapse">
				<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
					<ul class="nav" id="side-menu">
						<li>
							<a href="home.php" class="active"><i class="fa fa-home  nav_icon"></i>HOME</a>						</li>
						<li>
							<a href="#"><i class="fa fa-cogs nav_icon"></i>Event  <span class="fa arrow"></span></a>
							<ul class="nav nav-second-level collapse">
								<li>
									<a href="event.php">Add</a>								</li>
								<li>
									<a href="display_event.php">View</a>								</li>
							</ul>
							<!-- /nav-second-level -->
						</li>
						<li>
							<a href="display_eb.php" ><i class="fa fa-th-large nav_icon"></i>Event Booking</a>						</li>
							
						<li>
							<a href="display_contact.php"><i class="fa fa-envelope nav_icon"></i>Contact</a>						</li>
						
						
						<li>
							<a href="#"><i class="fa fa-table nav_icon"></i>Invoice<span class="fa arrow"></span> </a>
							<ul class="nav nav-second-level collapse">
								<li>
									<a href="invoice.php">Add</a>								</li>
								<li>
									<a href="display_invoice.php">View</a>								</li>
							</ul>					
								</li>
						</ul>
				</nav>
				</div>
		</div>