<?php
    
	 include("connection.php");
	
	 $x=$_REQUEST['d'];
	 mysqli_query($a,"delete from  sub_cat where sc_id=$x") or die ("delete fail");
	 header("location:display_sub.php");
?>