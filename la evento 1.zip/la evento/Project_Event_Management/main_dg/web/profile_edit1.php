<?php
session_start();
if(!isset($_SESSION['admin']))
{
   header("location:index.php?msq3=stop");
   exit(0);
 }
 $b=$_SESSION['admin'];
 
  
   include("connection.php");
   $e=$_REQUEST['e'];
   $q=mysqli_query($a,"select * from admin where aid=$e") or die("qf");
   $data=mysqli_fetch_array($q);
   if(isset($_REQUEST['Submit']))
   {
       extract($_POST);
	  
	 $fn=$_FILES['pic']['name'];
	       if($fn!="")
		   {
		   $path="photo/";
	   $old_fn=$data['photo'];
	   $old_n_path=$path.$old_fn;
	   unlink($old_n_path);
	   $npath=$path.$fn;
	   move_uploaded_file($_FILES['pic']['tmp_name'],$npath);
	   }
	   else
	   { $fn=$data['photo'];
	}		
	   mysqli_query($a,"update admin set photo='$fn', name='$nm',mobile='$mob',email='$em' where aid=$e" ) or die("update query fail");
	   $_SESSION['user_name']=$nm;
	   header("location:profile_admin.php");
	   
   }
   
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Profile Edit</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Event management, online events booking, best event booking, All events booking website, Events" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
</head> 
<body class="cbp-spmenu-push">
<form action="" method="post" enctype="multipart/form-data" name="form1" onSubmit="return f1();">

	<div class="main-content">
		<?php include("menu.php"); ?>
		
		<?php include("full_profile.php"); ?>
		
			<div id="page-wrapper">
			<div class="main-page signup-page">
				<h3 class="title1">Profile Edit</h3>
				
				<div class="sign-up-row widget-shadow">
					<h5>Personal Information :</h5>
					<div class="sign-u">
					  <div class="sign-up1">
							<h4>Photo* :</h4>
						</div>
						<div class="sign-up2">
							<label> <input name="pic" type="file" ><img src="photo/<?php echo $data['photo']; ?>" width="50" height="50"></label>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="sign-u">
						<div class="sign-up1">
							<h4>Full Name* :</h4>
						</div>
						<div class="sign-up2"><br>
							  <input name="nm" type="text" id="nm" value="<?php echo $z['name']; ?>" />	
							
							
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="sign-u">
						<div class="sign-up1">
							<h4>Mobile NO* :</h4>
						</div>
						<div class="sign-up2"><br>
							
								<input name="mob" type="text" id="mob"  value="<?php echo $z['mobile']; ?>" />	
							
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="sign-u">
						<div class="sign-up1">
							<h4>Email Address* :</h4>
						</div>
						<div class="sign-up2"><br>
								<input name="em" type="text" id="em"  value="<?php echo $z['email']; ?>"/>
					
						</div>
						<div class="clearfix"> </div>
					</div>
					
					
					
					<div class="sub_home" >
						
							  <input name="Submit" type="submit" id="Submit" value="Edit" />
						
						<div class="clearfix"> </div>
					</div>
				</div>
			</div>
		</div>
		
		<!--footer-->
		<?php 
		    include("footer.php");
		  ?>
        <!--//footer-->
	</div>
	<!-- Classie -->
		
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.js"> </script>
	
	</form>
</body>
</html>
<script>
function f1()
{
   if(form1.nm.value=="")
   {
        alert("Enter name");
		form1.nm.focus();
		return false;
		
	}
	else if(form1.mob.value=="")
	{
	   alert("Enter mobile No");
	   form1.mob.focus();
	   return false;
	  }
	 else if(form1.em.value=="")
	{
	   alert("Enter e-mail");
	   form1.em.focus();
	   return false;
	  }

}
	
</script>