
     function f1()
	 {
	   var a=confirm("Are you sure to edit data?")
	   if(a==false)
	   {
	      return false;
		 }
	}
	function f2()
	{
	   var b=confirm("Are you sure to delete data?")
	   
	   if(b==false)
	   {
	      return false;
		  }
		 }
		 