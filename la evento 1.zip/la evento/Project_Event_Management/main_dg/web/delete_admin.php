<?php
     include("connection.php");
	 $d=$_REQUEST['d'];
	 
	 //remove photo
	 $q=mysqli_query($a,"select photo from admin where aid=$d") or die("qf");
	 $data=mysqli_fetch_array($q);
	 $fn=$data['photo'];
	 $path="photo/";
	 $npath=$path.$fn;
	 unlink($npath);
	 
	 
	 
	mysqli_query($a,"delete from admin where aid=$d")or die("qf");
	header("location:display_admin.php");
?>