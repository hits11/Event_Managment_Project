<?php
session_start();
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Display Event</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
 
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>

<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
</head> 
<body class="cbp-spmenu-push">
	<div class="main-content">
	<?php include("menu.php"); ?>
	</div>
	<?php include("full_profile.php"); ?>
		
		<div id="page-wrapper">
		<?php
		if(isset($_SESSION['status']))
		{
		?>
		<script>
		swal({
  title: "<?php echo $_SESSION['status']; ?>",
  text: "",
  icon: "success",
  button: "ok",
});
		</script>
<?php
	
		unset($_SESSION['status']);
		}
		?>
			<div class="main-page">
				<div class="tables">
					<h3 class="title1">Event view</h3>
					<div class="panel-body widget-shadow">
						<form name="form1" id="form1" enctype="multipart/form-data">
					<table align="center" class="table" style="text-align:center;" width="100%" border="1" cellspacing="2" cellpadding="1">
  <tr>
    <td width="20%" height="83">NO</td>
    <td >Event_Name</td>
	 <td >Package 1</td>
	  <td >Package 2</td>
	   <td >Package 3</td>
    <td colspan="2">Action</td>
  </tr>
  <?php
    $no=1;
	include("connection.php");
	extract($_POST);
	$z=mysqli_query($a,"select * from event") or die("qf");
	while ($b=mysqli_fetch_array($z))
	{
   ?>
  <tr>
    <td width="14.28%" ><?php echo $no; ?></td>
    <td width="14.28%"><?php echo $b['e_name']; ?></td>
	<td width="14.28%"><img src="photo/<?php echo $b['package_1']; ?>"?url="photo/<?php echo $b['package_1']; ?>"height="100px" height="100px"></td>
	<td width="14.28%"><img src="photo/<?php echo $b['package_2']; ?>"?url="photo/<?php echo $b['package_2']; ?>"height="100px" height="100px"></td>
	<td width="14.28%"><img src="photo/<?php echo $b['package_3']; ?>"?url="photo/<?php echo $b['package_3']; ?>"height="100px" height="100px"></td>
   <td width="14%"><a href="edit_event.php?e=<?php echo $b['event_id']; ?>" onClick="return f1()">Edit</a></td>
    <td width="15%"><a href="delete_event.php?d=<?php echo $b['event_id']; ?>" onClick="return f2()">Delete</a></td>
  </tr>
  <?php
      $no++;
	  }
  ?>
</table>
			
			</form>		</div>
					
				</div>
			</div>
		</div>
		<!--footer-->
		<?php
		   include("footer.php");
		?>
        <!--//footer-->
	</div>
	<!-- Classie -->
		<script src="js/classie.js"></script>
		<script>
			var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
				showLeftPush = document.getElementById( 'showLeftPush' ),
				body = document.body;
				
			showLeftPush.onclick = function() {
				classie.toggle( this, 'active' );
				classie.toggle( body, 'cbp-spmenu-push-toright' );
				classie.toggle( menuLeft, 'cbp-spmenu-open' );
				disableOther( 'showLeftPush' );
			};
			
			function disableOther( button ) {
				if( button !== 'showLeftPush' ) {
					classie.toggle( showLeftPush, 'disabled' );
				}
			}
		</script>
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<script src="js/msg.js"> </script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.js"> </script>
</body>
</html>
