<?php
session_start();
if(!isset($_SESSION['admin']))
{
   header("location:index.php?msq3=stop");
   exit(0);
 }
 $b=$_SESSION['admin'];
 
  
   include("connection.php");
   $e=$_REQUEST['e'];
   $q=mysqli_query($a,"select * from admin where aid=$e") or die("qf");
   $z=mysqli_fetch_array($q);
   if(isset($_REQUEST['Submit']))
   {
       extract($_POST);
	   $fn=$_FILES['pic']['name'];
	       if($fn!="")
		   {
		
	   $old_fn=$z['photo'];
	   $old_n_path=$path.$old_fn;
	   unlink($old_n_path);
	   $npath=$path.$fn;
	   move_uploaded_file($_FILES['pic']['tmp_name'],$npath);
	   }
	   else
	   { $fn=$z['photo'];
	}
	   mysqli_query($a,"update admin set photo='$fn', name='$nm',mobile='$mob',email='$em',loginid='$lid' where aid=$e" ) or die("update query faail");
	   header("location:display_admin.php");
	   
   }
   
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Edit Admin</title>
</head>

<body>
<form action="" method="post">
  <table width="200" border="1" align="center" cellpadding="1" cellspacing="2">
    <tr>
      <td colspan="3"><div align="center">Admin Edit </div></td>
    </tr>
     <tr>
      <td>Photo</td>
      <td>:</td>
      <td><input name="pic" type="file" id="ph"  value="<?php echo $z['photo']; ?>"/><img src="photo/<?php echo $z['photo']; ?>"?url="photo/<?php echo $z['photo']; ?>"height="100px" height="100px"></td>
    </tr>
    <tr>
      <td>Name</td>
      <td>:</td>
      <td><input name="nm" type="text" id="nm" value="<?php echo $z['name']; ?>" /></td>
    </tr>
    <tr>
      <td>Mobile</td>
      <td>:</td>
      <td><input name="mob" type="text" id="mob"  value="<?php echo $z['mobile']; ?>" /></td>
    </tr>
    <tr>
      <td>E-mail</td>
      <td>:</td>
      <td><input name="em" type="text" id="em"  value="<?php echo $z['email']; ?>"/></td>
    </tr>
   
    <tr>
      <td>Login_id</td>
      <td>:</td>
      <td><input name="lid" type="text" id="lid"  value="<?php echo $z['loginid']; ?>" /></td>
    </tr>
    
    <tr>
      <td colspan="3"><div align="center">
        <input name="Submit" type="submit" id="Submit" value="Submit" />
      </div></td>
    </tr>
  </table>

</form>
<p>&nbsp;</p>
</body>
</html>
