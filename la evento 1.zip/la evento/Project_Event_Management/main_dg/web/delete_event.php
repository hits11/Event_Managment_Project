<?php
session_start();
     include("connection.php");
	 
	
	 $x=$_REQUEST['d'];
	 mysqli_query($a,"delete from  event where event_id=$x") or die ("delete fail");
	 header("location:display_event.php");
	 $_SESSION['status']="Data delete success fully";
	 
?>