
<?php
session_start();
?>
<?php 
     include("connection.php");
	 extract($_POST);
	    $e=$_REQUEST['e'];
		$q=mysqli_query($a,"select * from invoice where i_id=$e");
		$data=mysqli_fetch_array($q);
		if(isset($_REQUEST['btnsub']))
		{
		   
		   mysqli_query($a,"update invoice set event='$txtevent', package='$txtpackage', date='$txtdate',amount='$txtamt', sgst='$txtsg', cgst='$txtcg', discount='$txtdis', total='$txttotal' where i_id=$e");
		   header("location:display_invoice.php");
		   }
    ?>
<!DOCTYPE HTML>
<html>
<head>
<title>Edit Invoice</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Event management, online events booking, best event booking, All events booking website" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
</head> 
<body class="cbp-spmenu-push">
<form action="" method="post" onSubmit="return f1();" name="form1">
	<div class="main-content">
	<?php include("menu.php"); ?>
	<?php include("full_profile.php"); ?>
		<div id="page-wrapper">
			<div class="main-page signup-page">
				<h3 class="title1">Edit</h3>
				
				<div class="sign-up-row widget-shadow">
					
					<div class="sign-u">
						<div class="sign-up1">
							<h4>Event* :</h4>
						</div>
						<div class="sign-up2">
						<br>
							<select  class="form-control" name="txtevent" onBlur="return f2();">
							<option value="<?php echo $data['event']; ?>"><?php echo $data['event']; ?></option>
									<?php
							
							$q_menu=mysqli_query($a,"select e_name from event")or die("qf menu");
							while($data_m=mysqli_fetch_array($q_menu))
							{
							?>
							<option><?php echo $data_m['e_name'];?></option>
							<?php
							}
							?>
							</select>
								
							
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="sign-u">
						<div class="sign-up1">
							<h4>Package* :</h4>
						</div>
						<div class="sign-up2">
							<br>
								<select  class="form-control" name="txtpackage" onBlur="return f2();" id="txtpackage" onChange="return set();" >
								<option value="">Select Package</option>
							<option value="20000">Package 1</option>
							<option value="40000">Package 2</option>
							<option value="60000">Package 3</option>
							
							</select>
							
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="sign-u">
						<div class="sign-up1">
							<h4>Date* :</h4>
						</div>
						<div class="sign-up2">
							
								<input  class="form-control" name="txtdate" type="text" id="date"  value="<?php echo $data['date'];?>" />
							
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="sign-u">
						<div class="sign-up1">
							<h4>Amount* :</h4>
						</div>
						<div class="sign-up2">
							<input type="text"  class="form-control" name="txtamt" onBlur="return f2();" id="amt" readonly="" value="<?php echo $data['amount'];?>" >
								
							
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="sign-u">
						<div class="sign-up1">
							<h4>SGST* :</h4>
						</div>
						<div class="sign-up2">
							
								<input name="txtsg"  class="form-control" type="text" id="sg"  value="<?php echo $data['sgst'];?>"onBlur="return f2();" />
							
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="sign-u">
						<div class="sign-up1">
							<h4>CGST* :</h4>
						</div>
						<div class="sign-up2">
							
								<input name="txtcg"  class="form-control" type="text" id="cg"  value="<?php echo $data['cgst'];?>"onBlur="return f2();" />
							
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="sign-u">
						<div class="sign-up1">
							<h4>Discount* :</h4>
						</div>
						<div class="sign-up2">
							
								<input name="txtdis"  class="form-control" type="text" id="dis"  value="<?php echo $data['discount'];?>"onBlur="return f2();" />
							
						</div>
						<div class="clearfix"> </div>
					</div>
						<div class="sign-u">
						<div class="sign-up1">
							<h4>Total* :</h4>
						</div>
						<div class="sign-up2">
							
								<input name="txttotal"  class="form-control" type="text" id="total" value="<?php echo $data['total'];?>"onBlur="return f2();" readonly="" />
							
						</div>
						<div class="clearfix"> </div>
					</div>
					
						<div class="clearfix"> </div>
					</div>
					
					<div class="sub_home">
						
							<input type="submit" value="Submit" name="btnsub">
						
						<div class="clearfix"> </div>
					</div>
					
				</div>
			</div>
		</div>
		<!--footer-->
		<?php 
		    include("footer.php");
		  ?>
        <!--//footer-->
	</div>
	<!-- Classie -->
		
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.js"> </script>
	</form>
</body>
</html>
<script>
function f1()
{
   if(form1.txtevent.value=="")
   {
        alert("Select Event");
		form1.txtevent.focus();
		return false;
		
	}
	else if(form1.txtpackage.value=="")
	{
	   alert("Select Package");
	   form1.txtpackage.focus();
	   return false;
	  }
	 else if(form1.txtdate.value=="")
	{
	   alert("Enter date");
	   form1.txtdate.focus();
	   return false;
	  }
	   else if(form1.txtamt.value=="")
	{
	   alert("Enter amount");
	   form1.txtamt.focus();
	   return false;
	  }
	  else if(form1.txtsg.value=="")
	{
	   alert("Enter sgst");
	   form1.txtsg.focus();
	   return false;
	  }
	    else if(form1.txtcg.value=="")
	{
	   alert("Enter cgst");
	   form1.txtcg.focus();
	   return false;
	  }
	    else if(form1.txtdis.value=="")
	{
	   alert("Enter discount");
	   form1.txtdis.focus();
	   return false;
	  }
	    else if(form1.txttotal.value=="")
	{
	   alert("Enter total");
	   form1.txttotal.focus();
	   return false;
	  }
	 
}
function f2()
{   var amt=Number(form1.txtpackage.value);
    var sg=Number(form1.txtsg.value);
	var cg=Number(form1.txtcg.value);
	var dis=Number(form1.txtdis.value);
	var total=Number(form1.txttotal.value);
	var sg=(amt*sg)/100;
	var cg=(amt*cg)/100;
	var dis=(amt*dis)/100;
	var total=(amt+sg+cg)-dis;
	form1.txttotal.value=total;
}
function set(){
  var a=document.getElementById('txtpackage').value;
  
   document.getElementById('amt').value=a;
   document.getElementById('txtpackage');
}
	
</script>

