



<?php
 
   include("connection.php");
   $e=$_REQUEST['e'];
   $q=mysqli_query($a,"select * from event where event_id=$e") or die("qf");
   $data=mysqli_fetch_array($q);
   if(isset($_REQUEST['Submit']))
   {
       extract($_POST);
	  $fn=$_FILES['pic']['name'];
	       if($fn!="")
		   {
		   $path="photo/";
	   $old_fn=$data['package_1'];
	   $old_n_path=$path.$old_fn;
	   unlink($old_n_path);
	   $npath=$path.$fn;
	   move_uploaded_file($_FILES['pic']['tmp_name'],$npath);
	   }
		   else
	   { $fn=$data['package_1'];
	}
	  $fn1=$_FILES['pic1']['name'];
	       if($fn1!="")
		   {
		   $path="photo/";
	   $old_fn=$data['package_2'];
	   $old_n_path=$path.$old_fn;
	   unlink($old_n_path);
	   $npath=$path.$fn1;
	   move_uploaded_file($_FILES['pic1']['tmp_name'],$npath);
	   }
		   else
	   { $fn1=$data['package_2'];
	}
	  $fn2=$_FILES['pic2']['name'];
	       if($fn2!="")
		   {
		   $path="photo/";
	   $old_fn=$data['package_3'];
	   $old_n_path=$path.$old_fn;
	   unlink($old_n_path);
	   $npath=$path.$fn2;
	   move_uploaded_file($_FILES['pic2']['tmp_name'],$npath);
	   }
		   else
	   { $fn2=$data['package_3'];
	}
	
	 
	   mysqli_query($a,"update event set e_name='$nm', package_1='$fn',package_2='$fn1',package_3='$fn2' where event_id=$e" ) or die("update query faail");
	   $_SESSION['status']="Data Update success fully";
	   header("location:display_event.php");
	   
   }
   
?>
<!DOCTYPE HTML>
<html>
<head>
<title> Edit Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Event management, online events booking, best event booking, All events booking website" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
</head> 
<body class="cbp-spmenu-push">
<form action="" method="post" enctype="multipart/form-data" name="form1" onSubmit="return f1();">
	<div class="main-content">
	<?php include("menu.php"); ?>
	<?php include("full_profile.php"); ?>
		<div id="page-wrapper">
			<div class="main-page signup-page">
				<h3 class="title1">Edit</h3>
				
				<div class="sign-up-row widget-shadow">
					
					<div class="sign-u">
						<div class="sign-up1">
							<h4>Event Name* :</h4>
						</div>
						<div class="sign-up2">
							<input type="text"   class="form-control" name="nm" value="<?php echo $data['e_name']; ?>">
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="sign-u">
						<div class="sign-up1">
							<h4>Package 1* :</h4>
						</div>
						<div class="sign-up2">
							
						<input name="pic" type="file"   class="form-control" id="ph"  value="<?php echo $data['package_1']; ?>"/>.
						<img align="center" src="photo/<?php echo $data['package_1']; ?>"?url="photo/<?php echo $data['package_1']; ?>"height="100px" height="100px">	
						</div>
						<div class="clearfix"> </div>
					</div>
					
					<div class="sign-u">
						<div class="sign-up1">
							<h4>Package 2* :</h4>
						</div>
						<div class="sign-up2">
							<br>
								<input name="pic1" type="file"   class="form-control" id="ph"  value="<?php echo $data['package_2']; ?>"/>.
								<img src="photo/<?php echo $data['package_2']; ?>"?url="photo/<?php echo $data['package_2']; ?>"height="100px" height="100px">
							
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="sign-u">
						<div class="sign-up1">
							<h4>Package 3* :</h4>
						</div>
						<div class="sign-up2">
							<br>
								<input name="pic2" type="file"  class="form-control"  id="ph"  value="<?php echo $data['package_3']; ?>"/>.
								<img src="photo/<?php echo $data['package_3']; ?>"?url="photo/<?php echo $data['package_3']; ?>"height="100px" height="100px">
							
						</div>
						<div class="clearfix"> </div>
					</div>
					
					<div class="sub_home">
						
							<input type="submit" value="Add" name="Submit">
						
						<div class="clearfix"> </div>
					</div>
					
				</div>
			</div>
		</div>
		<!--footer-->
		<?php 
		    include("footer.php");
		  ?>
        <!--//footer-->
	</div>
	<!-- Classie -->
		
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.js"> </script>
	</form>
</body>
</html>
<script>
function f1()
{
   if(form1.nm.value=="")
   {
        alert("Enter event");
		form1.nm.focus();
		return false;
		
	}
	
  }
</script>
	  