<?php
     include("connection.php");
	 
	
	 $x=$_REQUEST['d'];
	 mysqli_query($a,"delete from  main_cat where mc_id=$x") or die ("delete fail");
	 header("location:display_main.php");
?>