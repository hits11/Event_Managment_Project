<?php
session_start();
if(!isset($_SESSION['admin']))
{
 header("location:index.php?msg3=stop");
 exit(0);
 }
 $b=$_SESSION['admin'];
 include("connection.php");
 $q=mysqli_query($a,"select * from admin where aid=$b") or die("qf");
 $z=mysqli_fetch_array($q);
 ?>
 <style>
	.logo{
		background: #0d2c54;
	}
	.fa fa-bars{
		background-color:  #0d2c54;
	}
 </style>
<div class="sticky-header header-section ">
			<div class="header-left" >
				<!--toggle button start-->
				<button id="showLeftPush"><i class="fa fa-bars"></i></button>
				<!--toggle button end-->
				<!--logo -->
				<div class="logo" >
					<a href="#">
						<h1>là</h1>
						<span>Evènto</span>
					</a>
				</div>
				<!--//logo-->
				<!--search-box-->
				<!--//end-search-box-->
				<div class="clearfix"> </div>
			</div>
			<div class="header-right">
				
				<!--notification menu end -->
				<div class="profile_details">		
					<ul>
						<li class="dropdown profile_details_drop">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
								<div class="profile_img">	
									<span class="prfil-img"><img src="photo/<?php echo $z['photo']; ?>"?url="photo/<?php echo $z['photo']; ?>"height="50px" height="50px"> </span> 
									<div class="user-name">
										<p>
										<?php 
										//check session have value in user_name
										if(isset($_SESSION['user_name'])){
											echo $_SESSION['user_name'];
										}
										 ?></p>
										<span>Administrator</span>
									</div>
									<i class="fa fa-angle-down lnr"></i>
									<i class="fa fa-angle-up lnr"></i>
									<div class="clearfix"></div>	
								</div>	
							</a>
							<ul class="dropdown-menu drp-mnu">
								
								<li> <a href="profile_admin.php"><i class="fa fa-user"></i> Profile</a> </li> 
								<li> <a href="change_password.php"><i class="fa  fa-exchange"></i> Change Password</a> </li> 
								<li> <a href="log_out.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
							</ul>
						</li>
					</ul>
				</div>
				<div class="clearfix"> </div>				
			</div>
			<div class="clearfix"> </div>	
		</div>