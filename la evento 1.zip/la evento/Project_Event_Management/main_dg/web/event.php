
<?php
 
						
   if(isset($_REQUEST['btnsub']))
   {
    
      
       //file upload
	     $fn=$_FILES['pic']['name'];
		 $path="photo/";
		 $npath=$path.$fn;
		 move_uploaded_file($_FILES['pic']['tmp_name'],$npath);
		 $fn1=$_FILES['pic1']['name'];
		 $path="photo/";
		 $npath=$path.$fn1;
		 move_uploaded_file($_FILES['pic1']['tmp_name'],$npath);
		 $fn2=$_FILES['pic2']['name'];
		 $path="photo/";
		 $npath=$path.$fn2;
		 move_uploaded_file($_FILES['pic2']['tmp_name'],$npath);
		 
       include("connection.php");
	  extract($_POST);
	  
	  
	   $qc=mysqli_query($a,"select e_name from event where e_name='$txtname'") or die("qf chack !");
	   
	   if(!mysqli_num_rows($qc))
	   {
	   
	   $q= mysqli_query($a,"INSERT INTO `event` (`e_name`,`package_1`,`package_2`,`package_3`) VALUES ('$txtname','$fn','$fn1','$fn2')") or die("query fail");
		if($q === true)
		 {
		 	$_SESSION['e_name']=$event_name;
			$_SESSION['status']="Data insert success fully";
		 	header("location:display_event.php");
		 }
		 else
		 {
		 
		    header("location:home.php");
		}
	}
	else
	{?>
	<script>
	alert("Please Enter Deffrent Event Name");
	</script>
	<?php
	}
	}
	?>
<!DOCTYPE HTML>
<html>
<head>
<title>Event</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Event management, online events booking, best event booking, All events booking website" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
</head> 
<body class="cbp-spmenu-push">
<form action="" method="post" enctype="multipart/form-data" name="form1" onSubmit="return f1();">
	<div class="main-content">
	<?php include("menu.php"); ?>
	<?php include("full_profile.php"); ?>
		<div id="page-wrapper">
			<div class="main-page signup-page">
				<h3 class="title1">Add</h3>
				
				<div class="sign-up-row widget-shadow">
					
					<div class="sign-u">
						<div class="sign-up1">
							<h4 class="form-label">Event Name <span style="color:red">*</span>  :</h4>
						</div>
						<div class="sign-up2">
							
								<input name="txtname" type="text" class="form-control" id="nm"  autofocus/>
							
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="sign-u">
						<div class="sign-up1">
							<h4 class="form-label">Package 1 <span style="color:red">*</span>  :</h4>
						</div>
						<div class="sign-up2">
							<br>
								<input name="pic" type="file" class="form-control"/>
							
						</div>
						<div class="clearfix"> </div>
					</div>
					
					<div class="sign-u">
						<div class="sign-up1">
							<h4 class="form-label">Package 2 <span style="color:red">*</span>  :</h4>
						</div>
						<div class="sign-up2">
							<br>
								<input name="pic1" type="file" class="form-control" />
							
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="sign-u">
						<div class="sign-up1">
							<h4 class="form-label">Package 3 <span style="color:red">*</span>  :</h4>
						</div>
						<div class="sign-up2">
							<br>
								<input name="pic2" type="file" class="form-control" />
							
						</div>
						<div class="clearfix"> </div>
					</div>
					
					<div class="sub_home">
						
							<input type="submit" value="Add" name="btnsub">
						
						<div class="clearfix"> </div>
					</div>
					
				</div>
			</div>
		</div>
		<!--footer-->
		<?php 
		    include("footer.php");
		  ?>
        <!--//footer-->
	</div>
	<!-- Classie -->
		
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.js"> </script>
	</form>
</body>
</html>
<script>
function f1()
{
   if(form1.txtname.value=="")
   {
        alert("Enter event");
		form1.txtname.focus();
		return false;
		
	}
	else if(form1.pic.value=="")
	{
	alert("Please Select image");
	form1.pic.focus();
	return false;
   }
   else if(form1.pic1.value=="")
	{
	alert("Please Select image-2");
	form1.pic1.focus();
	return false;
   }
   else if(form1.pic2.value=="")
	{
	alert("Please Select image-3");
	form1.pic2.focus();
	return false;
   }
	
}
</script>
	  