<?php
session_start();
?>   
<?php
   if(isset($_REQUEST['btnsub']))
   {
      include("connection.php");
	    extract($_POST);
		mysqli_query($a,"INSERT INTO `contact` (`name`, `email`, `subject`, `message`) VALUES ('$txtname', '$txtmail', '$txtsub', '$txtmsg')");
	    header("location:display_contact.php");
		
    }
	 
?>

<!DOCTYPE HTML>
<html>
<head>
<title>Contact</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Event management, online events booking, best event booking, All events booking website" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
</head> 
<body class="cbp-spmenu-push">
<form action="" method="post" name="form1" onSubmit="return f1();">
	<div class="main-content">
	<?php include("menu.php"); ?>
	<?php include("full_profile.php"); ?>
		<div id="page-wrapper">
			<div class="main-page signup-page">
				<h3 class="title1">Add</h3>
				
				<div class="sign-up-row widget-shadow">
					
					<div class="sign-u">
						<div class="sign-up1">
							<h4>Name* :</h4>
						</div>
						<div class="sign-up2">
							
								<input name="txtname" type="text" id="nm" autofocus />
							
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="sign-u">
						<div class="sign-up1">
							<h4>E-mail* :</h4>
						</div>
						<div class="sign-up2">
							
								<input name="txtmail" type="text" id="nm"  />
							
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="sign-u">
						<div class="sign-up1">
							<h4>Subject* :</h4>
						</div>
						<div class="sign-up2">
							
								<input name="txtsub" type="text" id="nm"  />
							
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="sign-u">
						<div class="sign-up1">
							<h4>Message* :</h4>
						</div>
						<div class="sign-up2">
							
								<input name="txtmsg" type="text" id="msg"  />
							
						</div>
						<div class="clearfix"> </div>
					</div>
					
						<div class="clearfix"> </div>
					</div>
					
					<div class="sub_home">
						
							<input type="submit" value="Submit" name="btnsub">
						
						<div class="clearfix"> </div>
					</div>
					
				</div>
			</div>
		</div>
		<!--footer-->
		<?php 
		    include("footer.php");
		  ?>
        <!--//footer-->
	</div>
	<!-- Classie -->
		
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.js"> </script>
	</form>
</body>
</html>
<script>
function f1()
{
   if(form1.txtname.value=="")
   {
        alert("Enter name");
		form1.txtname.focus();
		return false;
		
	}
	else if(form1.txtmail.value=="")
	{
	   alert("Enter email");
	   form1.txtmail.focus();
	   return false;
	  }
	 else if(form1.txtsub.value=="")
	{
	   alert("Enter subject");
	   form1.txtsub.focus();
	   return false;
	  }
	  else if(form1.txtmsg.value=="")
	{
	   alert("Enter message");
	   form1.txtmsg.focus();
	   return false;
	  }
	 
	}
	
</script>
