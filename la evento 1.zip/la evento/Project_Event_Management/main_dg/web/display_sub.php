<?php
session_start();
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Main Category view</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
</head> 
<body class="cbp-spmenu-push">
	<div class="main-content">
	<?php include("menu.php"); ?>
	</div>
	<?php include("full_profile.php"); ?>
		
		<div id="page-wrapper">
			<div class="main-page">
				<div class="tables">
					<h3 class="title1">Sub category view</h3>
					<div class="panel-body widget-shadow">
						
				 <table width="100%" border="1" cellspacing="2" cellpadding="1" height="100%">
    <tr>
      <td>No</td>
      <td>Mc_Name</td>
      <td colspan="2">Sc_Name</td>
      <td>Action</td>
    </tr>
	<?php
	$no=1;
     include("connection.php");
	 extract($_POST);
	 $q=mysqli_query($a,"select * from sub_cat") or die("query fail");
	 while($z=mysqli_fetch_array($q))
	 {
?>
    <tr>
      <td><?php echo $no; ?>&nbsp;</td>
      <td><?php echo $z['mc_name']; ?></td>
      <td><?php echo $z['sc_name']; ?></td>
      <td><a href="edit_sub.php?e=<?php  echo $z['sc_id'];?>"  onClick="return f1();">Edit</a></td>
      <td><a href="delete_sub.php?d=<?php echo $z['sc_id']; ?>" onClick="return f2();">Delete</a></td>
    </tr>
	<?php
	   $no++;
	   }
	   ?>
  </table>
					</div>
					
				</div>
			</div>
		</div>
		<!--footer-->
		<?php
		   include("footer.php");
		?>
        <!--//footer-->
	</div>
	<!-- Classie -->
		<script src="js/classie.js"></script>
		<script>
			var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
				showLeftPush = document.getElementById( 'showLeftPush' ),
				body = document.body;
				
			showLeftPush.onclick = function() {
				classie.toggle( this, 'active' );
				classie.toggle( body, 'cbp-spmenu-push-toright' );
				classie.toggle( menuLeft, 'cbp-spmenu-open' );
				disableOther( 'showLeftPush' );
			};
			
			function disableOther( button ) {
				if( button !== 'showLeftPush' ) {
					classie.toggle( showLeftPush, 'disabled' );
				}
			}
		</script>
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<script src="js/msg.js"> </script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.js"> </script>
</body>
</html>