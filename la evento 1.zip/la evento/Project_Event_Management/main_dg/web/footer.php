<div class="footer">
		   <p>&copy; 2025 Là Evènto. All Rights Reserved | Design by <a href="#">Là Evènto.</a></p>
		</div>