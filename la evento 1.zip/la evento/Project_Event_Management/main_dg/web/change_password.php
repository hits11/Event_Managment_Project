<?php
session_start();
	
if(!isset($_SESSION['admin']))
{
   header("location:index.php?msq3=stop");
   exit(0);
 }
 
	   if(isset($_REQUEST['btnchange']))
	   {
	   $b=$_SESSION['admin'];
	   extract($_POST);
   include("connection.php");
$q=mysqli_query($a,"select password from admin where aid='$b'")or die("qf");
$data=mysqli_fetch_array($q);
$old_pwd=$data['password'];

   if($old_pwd==$cp)
		 {
		   mysqli_query($a,"update admin set password='$np' where aid=$b")or die("qf");
		 	header("location:index.php");
		   }
		 else
		 { 
		 header("location:change_password.php?msg=wrong");
		 }
	}
           
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Change Password</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Event management, online events booking, best event booking, All events booking website" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
</head> 
<body class="cbp-spmenu-push">
<form action="" name="form1" method="post" onSubmit="return f1();">
	<div class="main-content">
	<?php include("menu.php"); ?>
	<?php include("full_profile.php"); ?>
		<div id="page-wrapper">
			<div class="main-page signup-page">
				<h3 class="title1">Change Password</h3>
				
				<div class="sign-up-row widget-shadow">
					
					<div class="sign-u">
						<div class="sign-up1">
							<h4>OLD Password* :</h4>
						</div>
						<div class="sign-up2">
							
								<input name="cp" type="text"  />
							
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="sign-u">
						<div class="sign-up1">
							<h4>NEW Password* :</h4>
						</div>
						<div class="sign-up2">
							
								<input name="np" type="Password" />
							
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="sign-u">
						<div class="sign-up1">
							<h4>Confirm Password* :</h4>
						</div>
						<div class="sign-up2">
							
								<input name="cnp" type="Password"  />
							
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="sub_home">
						
							<input type="submit" value="Submit" name="btnchange">
						
						<div class="clearfix"> </div>
					</div>
					
				</div>
			</div>
		</div>
		<!--footer-->
		<?php 
		    include("footer.php");
		  ?>
        <!--//footer-->
	</div>
	<!-- Classie -->
		
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.js"> </script>
	<script>
	function f1()
   {
   if(form1.cp.value=="")
   {
        alert("Enter Current password");
		form1.cp.focus();
		return false;	
	}
	else if(form1.np.value=="")
   {
        alert("Enter New password");
		form1.np.focus();
		return false;	
	}
	else if(form1.cnp.value=="")
   {
        alert("Enter Confirm password");
		form1.cnp.focus();
		return false;	
	}
}
	</script>
	</form>
</body>
</html>

