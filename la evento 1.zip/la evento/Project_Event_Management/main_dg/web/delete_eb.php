<?php
  include("connection.php");
  $x=$_REQUEST['d'];
  mysqli_query($a,"delete from eb where eid=$x");
  
  header("location:display_eb.php");
?>
