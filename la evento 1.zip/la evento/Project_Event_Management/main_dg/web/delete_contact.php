<?php
  include("connection.php");
     
	 
	 $d=$_REQUEST['d'];
	 mysqli_query($a,"delete from contact where c_id=$d");
	 header("location:display_contact.php");
	 
?>