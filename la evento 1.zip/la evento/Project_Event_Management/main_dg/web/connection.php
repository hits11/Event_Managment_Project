<?php
  $a= mysqli_connect("localhost","root","") or die("connection fail");
	 mysqli_select_db($a,"event")or die("database fail");
?>